package senai.aula07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula07Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula07Application.class, args);
	}

}
